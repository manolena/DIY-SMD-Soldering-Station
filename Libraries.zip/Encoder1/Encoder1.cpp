/*
 
	Created by WilliamK @ Wusik Dot Com (c) 2010
	http://arduino.wusik.com
 
*/

#include "Arduino.h"
#include "Encoder1.h"

// ------------------------------------------------------------------------------------------- //
Encoder1::Encoder1(int8_t pinLeft, int8_t pinRight, int8_t pinClick)
{ 
	encoderPinLeft = pinLeft;
	encoderPinRight = pinRight;
	encoderPinClick = pinClick;

	pinMode(encoderPinLeft, INPUT);
	digitalWrite(encoderPinLeft, HIGH);
	pinMode(encoderPinRight, INPUT);
	digitalWrite(encoderPinRight, HIGH);
	pinMode(encoderPinClick, INPUT);
	digitalWrite(encoderPinClick, HIGH);

	isClicked = false;
	prevClickValue = 1;
	integerMode = false;
	isClickedEvent = false;
	currentPosition = 0;
	prevPosition = 0;
	tempPosition = 0; 
	tempPosition2 = 0; 
	maxValue = 127; 
	minValue = 0;
	moveRate = 1.0f;
	timeLastClick = millis();
	timeClickStarted = 0;
}
// ------------------------------------------------------------------------------------------- //
void Encoder1::lowLevelTick(void)
{

    tempPosition2 = (digitalRead(encoderPinRight) * 4) + digitalRead(encoderPinLeft);
    if (encodeSeq[tempPosition2] == tempPosition)
	{
		currentPosition -= moveRate;
	}	
	else if (encodeSeq[tempPosition] == tempPosition2) 
	{
		currentPosition += moveRate;
	}		
    tempPosition = tempPosition2;

/*
	tempPosition2 = (digitalRead(encoderPinRight) * 1) + digitalRead(encoderPinLeft);
//	if (!digitalRead(encoderPinClick)) moveRate = 1.0f; else moveRate = 50.0f;
    if (encodeSeq[tempPosition2] == tempPosition) currentPosition -= moveRate;
	    else if (encodeSeq[tempPosition] == tempPosition2) currentPosition += moveRate;
    tempPosition = tempPosition2;
*/
}

// ------------------------------------------------------------------------------------------- //
void Encoder1::lowLevelClick(void)
{
	newClickValue = digitalRead(encoderPinClick);
	if (newClickValue != prevClickValue)
	{
		if ((millis() - timeLastClick) < clickDebounceTime) return;

		if (newClickValue == 0 && !isClicked) 
		{
			isClickedEvent = true;
			isClicked = true;
			timeClickStarted = millis();
		}
		else if (newClickValue == 1) isClicked = false; 
		timeLastClick = millis();
	}
	prevClickValue = newClickValue;
}

// ------------------------------------------------------------------------------------------- //
boolean Encoder1::onClickHold(void)
{
	if (isClicked && (millis() - timeClickStarted) >= clickHoldTime) return true;
	return false;
}
// ------------------------------------------------------------------------------------------- //
boolean Encoder1::hasClick(void)
{
	if (isClickedEvent)
	{
		isClickedEvent = false;
		return true;
	}

	return false;
}

// ------------------------------------------------------------------------------------------- //
void Encoder1::setIntegerMode(boolean mode)
{
	integerMode = mode;
}

// ------------------------------------------------------------------------------------------- //
boolean Encoder1::tick(void)
{ 
	lowLevelTick();
	lowLevelClick();
	
	return (hasChanged() || isClickedEvent);
}

// ------------------------------------------------------------------------------------------- //
boolean Encoder1::hasChanged()
{
	currentPosition = constrain(currentPosition, minValue, maxValue);

	if (integerMode)
	{
		if ((int)getPosition() != (int)prevPosition)
		{
			prevPosition = getPosition();
			return true;
		}
	}
	else
	{
		if (getPosition() != prevPosition)
		{
			prevPosition = getPosition();
			return true;
		}
	}

	return false;
}

// ------------------------------------------------------------------------------------------- //
float Encoder1::getPosition(void)
{
	if (integerMode) return (int)currentPosition;
	return currentPosition;
}

// ------------------------------------------------------------------------------------------- //
void Encoder1::setMinMax(float _min, float _max) 
{ 
	minValue = _min;
	maxValue = _max;

	currentPosition = constrain(currentPosition, minValue, maxValue);
}

// ------------------------------------------------------------------------------------------- //
void Encoder1::setPosition(float _position)
{
	currentPosition = _position;

	currentPosition = constrain(currentPosition, minValue, maxValue);
}

// ------------------------------------------------------------------------------------------- //
void Encoder1::setRate(float _rate)
{
	moveRate = _rate;
}