/*
 
	Created by WilliamK @ Wusik Dot Com (c) 2010
	http://arduino.wusik.com

*/

#ifndef ENCODER1_h
#define ENCODER1_h

#include <inttypes.h>
#include "HardwareSerial.h"

const int8_t encodeSeq[] = {1, 3, 0, 2};
#define clickDebounceTime 50
#define clickHoldTime 500

// ------------------------------------------------------------------------------------------- //
class Encoder1
{
public:
	Encoder1(int8_t pinLeft, int8_t pinRight, int8_t pinClick);
	boolean tick(void);
	void lowLevelTick(void);
	void lowLevelClick(void);
	float getPosition(void);
	void setMinMax(float _min, float _max);
	void setPosition(float _position);
	void setRate(float _rate);
	boolean hasChanged(void);
	boolean hasClick(void);
	boolean onClickHold(void);
	void setIntegerMode(boolean mode);

private:
	int8_t encoderPinLeft;
	int8_t encoderPinRight;
	int8_t encoderPinClick;

	float prevPosition;
	float maxValue;
	float minValue;
	float currentPosition;
	float moveRate;
	int8_t tempPosition;
	int8_t tempPosition2;
	boolean isForward;
	boolean isClickedEvent;
	boolean isClicked;
	int8_t prevClickValue;
	int8_t newClickValue;
	boolean integerMode;
	unsigned long timeLastClick;
	unsigned long timeClickStarted;
};

#endif