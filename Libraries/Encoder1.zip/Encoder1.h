/*
 
	Created by WilliamK @ Wusik Dot Com (c) 2010
	http://arduino.wusik.com

*/

#ifndef ENCODER1_h
#define ENCODER1_h

#if ARDUINO >= 100
    #include "Arduino.h"
#else
    #include "WProgram.h"
#endif
#include <inttypes.h>
#include "HardwareSerial.h"

const int8_t encodeSeq[] = {1, 3, 0, 2};
#define clickDebounceTime 200
#define clickHoldTime 1000
#define clickLongHoldTime 3000

// ------------------------------------------------------------------------------------------- //
class Encoder1
{
public:
	Encoder1(int8_t pinLeft, int8_t pinRight, int8_t pinClick);
	boolean tick(void);
	void lowLevelTick(float fastRate, float slowRate);
	void lowLevelClick(void);
	float getPosition(void);
	void setMinMax(float _min, float _max);
	void setPosition(float _position);
	void setRate(float _rate);
	boolean hasChanged(void);
	boolean hasClick(void);
	boolean onClickHold(void);
	void setIntegerMode(boolean mode);

private:
	int8_t encoderPinLeft;
	int8_t encoderPinRight;
	int8_t encoderPinClick;
    
	float fastRate;
	float slowRate;
	float prevPosition;
	float maxValue;
	float minValue;
	float currentPosition;
	float moveRate;
	int8_t tempPosition;
	int8_t tempPosition2;
	boolean isForward;
	boolean isClickedEvent;
	boolean longHoldEventPast;
	boolean holdEventPast;
	boolean isClicked;
	boolean buttonVal;   
	boolean buttonLast;  
	int8_t prevClickValue;
	int8_t newClickValue;
	boolean integerMode;
	unsigned long timeLastClick;
	unsigned long timeClickStarted;
};

#endif